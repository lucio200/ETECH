<?php
//conexion base de datos
require 'conexion1.php';
$perfiles = $mysqli->query("SELECT ced_rev, nom_rev, apell_rev FROM revisores");
?>



<?php
	include_once 'conexion.php';

	if(isset($_GET['id_eje'])){
		$id_eje=(int) $_GET['id_eje'];

		$buscar_id=$con->prepare('SELECT * FROM eje WHERE id_eje = :id_eje LIMIT 1');
		$buscar_id->execute(array(
			':id_eje'=>$id_eje
		));
		$resultado=$buscar_id->fetch();
	}else{
		header('Location: admin.php');
	}


	if(isset($_POST['guardar'])){
		
		$cedula_rev=$_POST['cedula_rev'];
		$id_eje=(int) $_GET['id_eje'];

		if(!empty($cedula_rev)){
			
				$consulta_update=$con->prepare(' UPDATE eje SET  
					cedula_rev=:cedula_rev
					WHERE id_eje=:id_eje;'
				);
				$consulta_update->execute(array(	
					':cedula_rev' =>$cedula_rev,
					':id_eje' =>$id_eje
				));
				
				$mensaje = "!Ingresado correctamente";
echo "<script type='text/javascript'> 
        alert('$mensaje');
        window.location.href = 'admin.php';
      </script>";
			
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}
	}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<title>Asignar Revisor</title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<div class="contenedor">
		<h2>Escoger Revisor</h2>
		<form action="" method="post">
			<div class="">
				<input type="text" name="nombre_eje" value="<?php if($resultado) echo $resultado['nombre_eje']; ?>" class="input__text">
                
				<select name="cedula_rev" class="form-select" aria-label="Default select example">
          <option>Escoger</option>
		  <?php
while($row = $perfiles->fetch_assoc()){ ?>
<option value ="<?php echo $row['ced_rev'];?>"> <?php echo $row['nom_rev'];?>  <?php echo $row['apell_rev'];?></option>
<?php }?>
</select>
			</div>
			<div class="btn__group">
				<a href="admin.php" class="btn btn__danger" id="salirBtn">Salir</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>

	

</body>
</html>