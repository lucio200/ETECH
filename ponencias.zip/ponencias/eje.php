



<?php
session_start(); // Inicia la sesión
require 'conexion1.php';

$perfiles = $mysqli->query("SELECT id, descripcion FROM institucion");
$perfiles1 = $mysqli->query("SELECT ced_po, nom_po, apell_po FROM ponencias");
$perfiles2 = $mysqli->query("SELECT ced_po, nom_po, apell_po FROM ponencias");
$ponencias = $mysqli->query("SELECT * FROM revisores r, eje e WHERE r.ced_rev = 1719213104");


// Consulta para obtener el ID deseado de la tabla
$resultado = $mysqli->query("SELECT * FROM revisores r , eje e WHERE r.ced_rev = 1719213104 ORDER BY r.ced_rev DESC LIMIT 1");
//$resultado = $mysqli->query("SELECT p.ced_po, r.ced_rev FROM ponencias p INNER JOIN revisores r ON p.ced_po = r.ced_rev ORDER BY p.ced_po DESC LIMIT 1 WHERE r.ced_rev = 1719213104");

// Verifica si la consulta se ejecutó correctamente y si se encontraron resultados
if ($resultado && $resultado->num_rows > 0) {
    // Obtiene la primera fila de resultados
    $fila = $resultado->fetch_assoc();
    // Obtiene el ID de la fila
	$ced_rev = $fila['ced_rev'];
	$estado_eje = $fila['estado_eje'];
	$observa_eje =$fila['observa_eje'];
	$filenamer =$fila['filenamer'];
	$filesizer =$fila['filesizer'];
	$filetyper =$fila['filetyper'];

} else {
    // Si no se encontraron resultados o la consulta falló, asigna un valor predeterminado
	$ced_rev = "1719213104";
	$estado_eje = "N/A";
	$observa_eje = "N/A";
	$filenamer = "N/A";
	$filesizer = "0";
	$filetyper = "N/A";
}
    $filenamer = "N/A";
	$filesizer = "0";
	$filetyper = "N/A";
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro del Proyecto</title>
	<link rel="stylesheet" href="css/estilo.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
	
	
	<div class="contenedor">
	<h2>Ingreso de del Proyecto</h2>

	<br>
		<div class ="form-group">
		<select name = "cedula" id="dataSelect" class="form-select form-select-sm" aria-label="Small select example">
<option>Seleccionar Autores</option>
<?php
while($row = $perfiles2->fetch_assoc()){ ?>
<option value="<?php echo $row['ced_po']; ?>"><?php echo $row['nom_po'] . ' ' . $row['apell_po']; ?></option>
<?php }?>
</select>
		<button onclick="agregarDato()" class="btn btn_primary">Agregar</button><br>
		</div>
		<br>
		<div class = "form-group">
		<textarea id="selectedData" readonly cols="50" Placeholder = "Autores"></textarea>
		<script>
        function agregarDato() {
            var select = document.getElementById("dataSelect");
            var selectedOption = select.options[select.selectedIndex];
            var selectedText = selectedOption.text;
            var selectedValue = selectedOption.value;
            
            var textarea = document.getElementById("selectedData");
            // var listbox = document.getElementById("selectedData"); // Para ListBox
            
            // textarea.options[textarea.options.length] = new Option(selectedText, selectedValue); // Para ListBox
            textarea.value += selectedText + "\n";
        }
    </script>
		</div>

<br>
		<form action="upload.php" method="POST" enctype="multipart/form-data">
		<div class="form-group">
		<select name = "cedula_po" class="form-select form-select-sm" aria-label="Small select example">
<option>Seleccionar Autor Principal</option>
<?php
while($row = $perfiles1->fetch_assoc()){ ?>
<option value="<?php echo $row['ced_po']; ?>"><?php echo $row['nom_po'] . ' ' . $row['apell_po']; ?></option>
<?php }?>
</select>
		<input type="hidden" name="cedula_rev" class="input__text"  value="<?php echo $ced_rev; ?>">
		<input type="hidden" name="estado_eje" class="input__text"  value="<?php echo $estado_eje; ?>">
		<input type="hidden" name="observa_eje" class="input__text"  value="<?php echo $observa_eje; ?>">
         
		<input type="hidden" name="filenamer" class="input__text"  value="<?php echo $filenamer; ?>">
		<input type="hidden" name="filesizer" class="input__text"  value="<?php echo $filesizer; ?>">
		<input type="hidden" name="filetyper" class="input__text"  value="<?php echo $filetyper; ?>">


		<select name= "nombre_eje" class="form-select form-select-sm" aria-label="Small select example">
					<option>Seleccionar Eje</option>
					<option> Desarrollo Sostenible</option>
					<option> Innovación Educativa en la Formación Técnica y Tecnológica</option>
					<option> Desarrollo Integral para la Salud</option>
				</select>
        </div>  
		
		<br>
		<div class="form-group">
		<input type="Text" name="tema_eje" placeholder = "Tema">
		</div>
		<br>
			<div class="form-group">
			<textarea name="resumen_eje" id = "resumen_eje" rows="10" cols="50" placeholder="Resumen"></textarea>	
			</div>
			<br>
			<label>Fecha de Entrega</label>
			<div class="form-group">
			<input type="date" name="fechaentrega_eje" id = "fechaentrega_eje" onClick="">	
            </div>	
		<div class="container mt-5">
			     <label>Solo admite archivo formato PDF Máximo 25MB</label>
				<input type="file" class="form-control" name="file" id = "file">
				<a href="index.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardar" id="guardar"  class="btn btn-primary">
				
			</div>
		</form>
	</div>
	
</body>
</html>
