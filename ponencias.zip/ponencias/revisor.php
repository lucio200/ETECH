<?php 
	include_once 'conexion.php';
	
	if(isset($_POST['guardar'])){
		$nombres_rev=$_POST['nombres_rev'];
		$apellidos_rev=$_POST['apellidos_rev'];
		$cedula_rev=$_POST['cedula_rev'];
		$celular_rev=$_POST['celular_rev'];
		$correo_rev=$_POST['correo_rev'];
		$areaconocimiento=$_POST['areaconocimiento'];
		

		if(!empty($nombres_rev) && !empty($apellidos_rev) && !empty($cedula_rev) && !empty($celular_rev) && !empty($correo_rev) && !empty($areaconocimiento)){
			if(!filter_var($correo_rev,FILTER_VALIDATE_EMAIL)){
				echo "<script> alert('Correo no valido');</script>";
			}else{
				$consulta_insert=$con->prepare('INSERT INTO revisores(nombres_rev, apellidos_rev, cedula_rev, celular_rev, correo_rev, areaconocimiento) VALUES(:nombres_rev,:apellidos_rev,:cedula_rev,:celular_rev,:correo_rev,:areaconocimiento)');
				$consulta_insert->execute(array(
					':nombres_rev' =>$nombres_rev,
					':apellidos_rev' =>$apellidos_rev,
					':cedula_rev' =>$cedula_rev,
					':celular_rev' =>$celular_rev,
					':correo_rev' =>$correo_rev,
					':areaconocimiento' =>$areaconocimiento
				));
				
				header('Location: revisor.php');
			}
			
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}

	}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro de Revisores</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>Ingreso de Revisores</h2>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="nombres_rev" placeholder="Nombre" class="input__text">
				<input type="text" name="apellidos_rev" placeholder="Apellido" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="cedula_rev" placeholder="Cédula" class="input__text">
				<input type="text" name="celular_rev" placeholder="Celular" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="correo_rev" placeholder="Correo" class="input__text">
			</div>
			<select name= "areaconocimiento" class="form-select form-select-sm" aria-label="Small select example">
					<option> Area de Conocimiento</option>
					<option> Desarrollo Sostenible</option>
					<option> Innovación Educativa en la Formación Técnica y Tecnológica</option>
					<option> Desarrollo Integral para la Salud</option>
				</select>		
			<div class="btn__group">
				<a href="menurevisor.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>
</body>
</html>