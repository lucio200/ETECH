<?php
	include_once 'conexion.php';

	if(isset($_GET['id_po'])){
		$id_po=(int) $_GET['id_po'];
        
		$buscar_id=$con->prepare('SELECT * FROM ponencias WHERE id_po = :id_po LIMIT 1');
		$buscar_id->execute(array(
			':id_po'=>$id_po
		));
		$resultado=$buscar_id->fetch();
	}else{
		header('Location: menuponencias.php');
	}


	if(isset($_POST['guardar'])){
		$nombre_po=$_POST['nombre_po'];
		$apellido_po=$_POST['apellido_po'];
        $cedula_po=$_POST['cedula_po'];
		$celular_po=$_POST['celular_po'];
		$correo_po=$_POST['correo_po'];
		$institucion_po=$_POST['institucion_po'];
        $titulo_po=$_POST['titulo_po'];
		$id_po=(int) $_GET['id_po'];

		if(!empty($nombre_po) && !empty($apellido_po) && !empty($cedula_po) && !empty($celular_po) && !empty($correo_po) && !empty($institucion_po) && !empty($titulo_po)){
			if(!filter_var($correo_po,FILTER_VALIDATE_EMAIL)){
				echo "<script> alert('Correo no valido');</script>";
			}else{
				$consulta_update=$con->prepare(' UPDATE ponencias SET  
					nombre_po=:nombre_po,
					apellido_po=:apellido_po,
					cedula_po=:cedula_po,
                    celular_po=:celular_po,
					correo_po=:correo_po,
					institucion_po=:institucion_po,
                    titulo_po=:titulo_po
					WHERE id_po=:id_po;'
				);
				$consulta_update->execute(array(
					':nombre_po' =>$nombre_po,
					':apellido_po' =>$apellido_po,
					':cedula_po' =>$cedula_po,
                    ':celular_po' =>$celular_po,
					':correo_po' =>$correo_po,
					':institucion_po' =>$institucion_po,
                    ':titulo_po' =>$titulo_po,
					':id_po' =>$id_po
				));
				header('Location: registroponencias.php');
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Editar Ponencia</title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<div class="contenedor">
		<h2>Edición de Ponencias</h2>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="nombre_po" value="<?php if($resultado) echo $resultado['nombre_po']; ?>" class="input__text">
				<input type="text" name="apellido_po" value="<?php if($resultado) echo $resultado['apellido_po']; ?>" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="cedula_po" value="<?php if($resultado) echo $resultado['cedula_po']; ?>" class="input__text">
				<input type="text" name="celular_po" value="<?php if($resultado) echo $resultado['celular_po']; ?>" class="input__text">
			</div>
			<div class="form-group">
            <input type="text" name="correo_po" value="<?php if($resultado) echo $resultado['correo_po']; ?>" class="input__text">
				<input type="text" name="institucion_po" value="<?php if($resultado) echo $resultado['institucion_po']; ?>" class="input__text">
			</div>
            <div class="form-group">
            <input type="text" name="titulo_po" value="<?php if($resultado) echo $resultado['titulo_po']; ?>" class="input__text">
            </div>
			<div class="btn__group">
				<a href="index.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>
</body>
</html>