<?php
//conexion base de datos
require 'conexion1.php';
$perfiles = $mysqli->query("SELECT id, descripcion FROM institucion WHERE id != 1");
?>

<?php 
	include_once 'conexion.php';
	
	if(isset($_POST['guardarp'])){
		$ced_po=$_POST['ced_po'];
		$nom_po=$_POST['nom_po'];
		$apell_po=$_POST['apell_po'];
		$cel_po=$_POST['cel_po'];
		$mail_po=$_POST['mail_po'];
		$tit_po=$_POST['tit_po'];
		$id_institucion=$_POST['id_institucion'];
		

		if(!empty($ced_po) && !empty($nom_po) && !empty($apell_po) && !empty($cel_po) && !empty($mail_po) && !empty($tit_po) && !empty($id_institucion)){
			if(!filter_var($ced_po,FILTER_VALIDATE_INT)){
				echo "<script> alert('Cedula no valida');</script>";
			}else{
				$consulta_insert=$con->prepare('INSERT INTO ponencias(ced_po, nom_po, apell_po, cel_po, mail_po, tit_po, id_institucion) VALUES(:ced_po, :nom_po,:apell_po,:cel_po,:mail_po,:tit_po,:id_institucion)');
				$consulta_insert->execute(array(
					':ced_po' =>$ced_po,
					':nom_po' =>$nom_po,
					':apell_po' =>$apell_po,
					':cel_po' =>$cel_po,
					':mail_po' =>$mail_po,
					':tit_po' =>$tit_po,
					':id_institucion' =>$id_institucion
				));
				$mensaje = "!Ingresado correctamente";
                echo "<script type='text/javascript'> 
                        alert('$mensaje');
                        window.location.href = 'eje.php';
                      </script>";
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}

	}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro de Datos</title>
	<link rel="stylesheet" href="css/estilo.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
	<div class="contenedor">
		<h2>Registro Autor</h2>
		<form action="ponencias.php" method="post">
			<div class="form-group">
				<input type="text" name="nom_po" placeholder="Nombre" class="input__text">
				<input type="text" name="apell_po" placeholder="Apellido" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="ced_po" placeholder="Cédula" class="input__text">
				<input type="text" name="cel_po" placeholder="Celular" class="input__text">
			</div>
			<div class="form-group">
			<input type="text" name="tit_po" placeholder="ORCID" class="input__text">
			<input type="text" name="mail_po" placeholder="Correo" class="input__text">
			</div>	
	
    
<select name = "id_institucion" class="form-select form-select-sm" aria-label="Small select example">
<option>Seleccionar el Instituto</option>
<?php
while($row = $perfiles->fetch_assoc()){ ?>
<option value ="<?php echo $row['id'];?>"> <?php echo $row['descripcion'];?></option>
<?php }?>
</select>

			<div class="btn__group">
				<a href="menuponencias.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardarp"   class="btn btn__primary">
				
			</div>
		</form>
	</div>

	
</body>
</html>