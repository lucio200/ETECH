<?php
if(isset($_POST['enviar'])){
    if(!empty($_POST['name']) && !empty($_POST['asunto'] && !empty($_POST['msj']) && !empty($_POST['email']))){
        $name = $_POST['name'];
        $asunto = $_POST['asunto'];
		$msj = $_POST['msj'];
		$email = $_POST['email'];        
        $header = "From: noreply@example.com"."\r\n";
        $header = "Replay-To: noreply@example.com"."\r\n";
        $header = "X-Mailer: PHP/". phpversion();
        $mail = mail($email, $asunto, $msg, $header);
        if($mail){
        echo "<h4>¡Mail enviado existosamente!</h4>";
        }
    }
}
?>