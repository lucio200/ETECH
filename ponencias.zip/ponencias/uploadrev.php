<?php
session_start(); // Inicia la sesión
require 'conexion1.php';
$ponencias = $mysqli->query("SELECT * FROM eje");

$nombre_eje = "N/A"; // Inicializa la variable $nombre_eje

// Consulta para obtener el ID deseado de la tabla
$resultado = $mysqli->query("SELECT id_eje, nombre_eje FROM eje  WHERE id_eje = :id_eje DESC LIMIT 1");

// Verifica si la consulta se ejecutó correctamente y si se encontraron resultados
if ($resultado && $resultado->num_rows > 0) {
    // Obtiene la primera fila de resultados
    $fila = $resultado->fetch_assoc();
    // Obtiene el nombre del eje de la fila
    $nombre_eje = $fila['nombre_eje'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "acceso";

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Inicializa las variables para el archivo
    $filenamer = "";
    $filesizer = "";
    $filetyper = "";

    // Check if a file was uploaded without errors
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $id_eje = (int) $_GET['id_eje'];
        $target_dir = "uploads/"; // Cambia esto al directorio deseado para los archivos cargados
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is allowed (you can modify this to allow specific file types)
        $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf");
        if (!in_array($file_type, $allowed_types)) {
            echo "Solo admite formato PDF";
            exit();
            header('Location: menuponencias.php');
        } else {
            // Move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                $filenamer = $_FILES["file"]["name"];
                $filesizer = $_FILES["file"]["size"];
                $filetyper = $_FILES["file"]["type"];
            } else {
                echo "No se ha podido cargar la información";
            }
        }
    }


    // Retrieve other form data
    $nombre_eje = $_POST['nombre_eje'];
    $estado_eje = $_POST['estado_eje'];
    $observa_eje = $_POST['observa_eje'];
    
    // Add more fields as needed

    // Get the ID of the record you want to update
    $id_eje = $_POST['id_eje']; // Assuming you have a hidden input field in your form containing the ID

    // SQL query for update
    $sql = "UPDATE eje SET nombre_eje='$nombre_eje', estado_eje='$estado_eje', observa_eje='$observa_eje', filenamer='$filenamer', filesizer=$filesizer, filetyper='$filetyper' WHERE id_eje=$id_eje";

    if ($conn->query($sql) === TRUE) {
        echo "Registro actualizado correctamente";
        $mensaje = "!Actualizado correctamente";
        echo "<script type='text/javascript'> 
                alert('$mensaje');
                window.location.href = 'menuponencias.php';
              </script>";
    } else {
        echo "Los sentimos a ocurrido un error al actualizar en la base de datos " . $conn->error;
    }

    $conn->close();
}
?>