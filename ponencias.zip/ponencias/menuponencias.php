

<?php
	include 'conexion1.php';
  include 'conexion.php';
	$sql= "select * from ponencias p 
	INNER JOIN eje e ON p.ced_po = e.cedula_po";
 
  $resultado1 =mysqli_query($conexion,$sql);
?>

<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT * FROM ponencias p INNER JOIN eje e ON p.ced_po = e.cedula_po ORDER BY p.ced_po DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT * FROM ponencias p INNER JOIN eje e ON p.ced_po = e.cedula_po WHERE p.nom_po LIKE :campo OR p.ced_po LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}
?>

<?php
//database connection details

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "acceso";

 $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);


 if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

 //Fetch the uploaded files from the database

 $sql = "select * from eje e 
 INNER JOIN ponencias p ON e.cedula_po  = p.ced_po
 ";
 $result = $conn->query($sql);

?>

<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MENU PONENCIAS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/estilo.css"> 
  </head>
  <body>
  

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
      <img src="\incelab\IMG\Logo.ico" alt="Incetronix" width="30" height="24">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Gestión
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="ponencias.php">Autores</a></li>
            <li><a class="dropdown-item" href="eje.php">Proyecto</a></li> 
			<li><a class="dropdown-item" href=""></a></li>           
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-disabled="true">Preguntas</a>
        </li>
      </ul>
    </div>
  </div>
</nav>




<div class="contenedor">
<h2>BIENVENIDO AL MENÚ DE PONENCIAS</h2>

<div class="contenedor">
		<h2></h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="Buscar Nombre o Cédula" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
				<a href="ponencias.php" class="btn btn__nuevo">Nuevo</a>
        <a href="index.php" class="btn btn__danger">Salir</a>
			</form>
		</div>
		<table>
			<tr class="head">
				
				<td>Tema</td>
				<td>Autor</td>
				<td>Fecha</td>
				<td>Correo</td>
				<td>ORCID</td>
			  <td>Eje</td>
			  <td colspan="3">Acciones</td> 
			</tr>

			<?php 
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$file_path = "uploads/" . $row['filenamer'];
				?>
				<tr >
					<td><?php echo $row['tema_eje']; ?></td>
					<td><?php echo $row['nom_po']; ?></td>
					<td><?php echo $row['ced_po']; ?></td>
					<td><?php echo $row['mail_po']; ?></td>
					<td><?php echo $row['tit_po']; ?></td>
                    <td><?php echo $row['nombre_eje']; ?></td>
					<td><a href="<?php echo $file_path; ?>" class="btn btn-light" download>Descargar</a></td>
							
				</tr>
			<?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="4">No hay documentos disponibles.</td>
                    </tr>
                    <?php
                }
                ?>
		</table>
	</div>



















<script src ="/incelab/js/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script> 

</body>
</html>