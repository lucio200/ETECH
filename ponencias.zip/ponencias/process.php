<?php
$perfiles = $mysqli->query("SELECT id, descripcion FROM cargo");
?>
<?php 
  $db = mysqli_connect('localhost', 'root', '', 'acceso');
  if (isset($_POST['username_check'])) {
        $usuario = $_POST['usuario'];
        $sql = "SELECT * FROM usuarios WHERE usuario='$usuario'";
        $results = mysqli_query($db, $sql);
        if (mysqli_num_rows($results) > 0) {
          echo "taken"; 
        }else{
          echo 'not_taken';
        }
        exit();
  }
  if (isset($_POST['email_check'])) {
        $contrasenia = $_POST['contrasenia'];
        $sql = "SELECT * FROM usuarios WHERE contrasenia='$contrasenia'";
        $results = mysqli_query($db, $sql);
        if (mysqli_num_rows($results) > 0) {
          echo "taken"; 
        }else{
          echo 'not_taken';
        }
        exit();
  }
  if (isset($_POST['guardar'])) {
        $usuario = $_POST['usuario'];
        $contrasenia = $_POST['contrasenia'];
        $id_cargo = $_POST['id_cargo'];
        $sql = "SELECT * FROM usuarios WHERE usuario='$usuario'";
        $results = mysqli_query($db, $sql);
        if (mysqli_num_rows($results) > 0) {
          echo "exists";        
          exit();
        }else{
          $query = "INSERT INTO usuarios (usuario,contrasenia, id_cargo) 
                VALUES ('$usuario', '$contrasenia', '".md5($id_cargo)."')";
          $results = mysqli_query($db, $query);
          echo 'Saved!';
          exit();
        }
  }

?>