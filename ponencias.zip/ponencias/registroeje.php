<?php
	include 'conexion1.php';
  include 'conexion.php';
	$sql= "select * from eje e INNER JOIN ponencias p
  ON e.cedula_po  = p.ced_po";
 
  $resultado1 =mysqli_query($conexion,$sql);
?>

<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT * FROM eje e INNER JOIN ponencias p ON e.cedula_po  = p.ced_po ORDER BY e.id_eje DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT * FROM eje e INNER JOIN ponencias p ON e.cedula_po  = p.ced_po WHERE p.nom_po LIKE :campo OR p.ced_po LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Inicio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  
</head>
<body>
	<div class="contenedor">
		<h2>REGISTRO EJES</h2>
		<div class="container text-center">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="buscar nombre o cédula" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn btn-success" name="btn_buscar" value="Buscar">
				<a href="eje.php" class="btn btn-success">Nuevo</a>
				<a href="menurevisor.php" class="btn btn-success">Salir</a>
			</form>
		</div>
		<table  class="table table-bordered">
        <thead class="table-light">
			<tr class="head">    
				
				<td>Nombre Eje</td>
				<td>Resumen</td>
				<td>Fecha Entrega</td>
				<td>Estado</td>
				<td>Observaciones</td>
                <td>Ponente</td>
                <td>Cédula</td>
				<td colspan="3">Acción</td>
			</tr>
            </thead>
			<?php foreach($resultado as $fila):?>
				<tr >
					
					<td><?php echo $fila['nombre_eje']; ?></td>
					<td><?php echo $fila['resumen_eje']; ?></td>
					<td><?php echo $fila['fechaentrega_eje']; ?></td>
					<td><?php echo $fila['estado_eje']; ?></td>
					<td><?php echo $fila['observa_eje']; ?></td>
                    <td><?php echo $fila['nom_po']; ?></td>
                    <td><?php echo $fila['ced_po']; ?></td>
					
					<td><a href="actualizareje.php?id_eje=<?php echo $fila['id_eje']; ?>"  class="btn btn-dark" >Aprobar</a></td>
					<!--<td><a href="borrareje.php?id_eje=<?php echo $fila['id_eje']; ?>" class="btn btn-dark">Eliminar</a></td>-->
					
				</tr>
			<?php endforeach ?>

		</table>
	</div>
</body>
</html>