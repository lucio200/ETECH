<?php
//conexion base de datos
require 'conexion1.php';
$perfiles = $mysqli->query("SELECT id, descripcion FROM institucion");
$perfiles1 = $mysqli->query("SELECT ced_po, nom_po, apell_po FROM ponencias");
?>

<?php 
	include_once 'conexion.php';
	
	if(isset($_POST['guardarp'])){
		$orcid=$_POST['orcid'];
		$tema=$_POST['tema'];
		$autor=$_POST['autor'];
		$ced_ponencias=$_POST['ced_ponencias'];
		$id_institucion=$_POST['id_institucion'];
		

		if(!empty($orcid) && !empty($tema) && !empty($autor) && !empty($ced_ponencias) && !empty($id_institucion)){
			if(!filter_var($orcid,FILTER_VALIDATE_INT)){
				echo "<script> alert('ORCID no Válido');</script>";
			}else{
				$consulta_insert=$con->prepare('INSERT INTO proyecto(orcid, tema, autor, ced_ponencias, id_institucion) VALUES(:orcid, :tema,:autor,:ced_ponencias,:id_institucion)');
				$consulta_insert->execute(array(
					':orcid' =>$orcid,
					':tema' =>$tema,
					':autor' =>$autor,
					':ced_ponencias' =>$ced_ponencias,
					':id_institucion' =>$id_institucion
				));
				$mensaje = "!Ingresado correctamente";
                echo "<script type='text/javascript'> 
                        alert('$mensaje');
                        window.location.href = 'menuponencias.php';
                      </script>";
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}

	}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro Proyecto</title>
	<link rel="stylesheet" href="css/estilo.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
	<div class="contenedor">
		<h2>Ingreso del Proyecto</h2>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="orcid" placeholder="Ingresar ORCID" class="input__text">
				<input type="text" name="tema" placeholder="Ingresa el Tema" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="autor" placeholder="Ingresar Autor" class="input__text">
			</div>

            <select name = "ced_ponencias" class="form-select form-select-sm" aria-label="Small select example">
<option>Seleccionar Nombre</option>
<?php
while($row = $perfiles1->fetch_assoc()){ ?>
<option value="<?php echo $row['ced_po']; ?>"><?php echo $row['nom_po'] . ' ' . $row['apell_po']; ?></option>
<?php }?>
</select>
            <br>
<select name = "id_institucion" class="form-select form-select-sm" aria-label="Small select example">
<option>Seleccionar el Instituto</option>
<?php
while($row = $perfiles->fetch_assoc()){ ?>
<option value ="<?php echo $row['id'];?>"> <?php echo $row['descripcion'];?></option>
<?php }?>
</select>

			<div class="btn__group">
				<a href="menuponencias.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardarp"   class="btn btn__primary">
				
			</div>
		</form>
	</div>

	
</body>
</html>