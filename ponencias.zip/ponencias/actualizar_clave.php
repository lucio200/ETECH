<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT * FROM usuarios ORDER BY id DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT * FROM usuarios WHERE id LIKE :campo OR usuario LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}


    ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>ICAMBIO_CLAVE</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>BUSCAR USUARIO</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="Ingresar la cédula" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
			</form>

          

<?php
	if(isset($_POST['guardar'])){
		$contrasenia=$_POST['contrasenia'];
		$id=(int) $_GET['id'];

		if(!empty($usuario) && !empty($contrasenia)){
			if(!filter_var($contrasenia,FILTER_VALIDATE_INT)){
				echo "<script> alert('Correo no valido');</script>";
			}else{
				$consulta_update=$con->prepare(' UPDATE usuarios SET  
					contrasenia = :contrasenia,
					WHERE usuario = :id;'
				);
				$consulta_update->execute(array(
					':contrasenia' =>$contrasenia,
					':id' =>$id
				));
				header('Location: index.php');
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}
	}

?>

<div class="contenedor">
		<h2>RECUPERACION DE CONTRASEÑA</h2>
        <h3>NUEVA CLAVE</h3>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="contrasenia" value="<?php if($resultado) echo $resultado['contrasenia']; ?>" class="input__text">
			</div>
			<div class="btn__group">
				<a href="index.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>
</body>
</html>