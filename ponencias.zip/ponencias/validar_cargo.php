<?php
require_once('config.php');
$usuario = $_POST['usuario'];
$clave = $_POST['contrasenia'];

$query = "SELECT u.id, u.usuario, u.contrasenia, c.descripcion FROM usuarios u left join cargo c ON u.id_cargo = c.id where usuario = '$usuario' AND contrasenia = '$contrasenia' AND status = 1";
$result = $conexion->query($query);
$row = $result->fetch_assoc();

if($result->num_rows > 0){
    session_start();
    $_SESSION['usuario'] = $usuario;
    $_SESSION['cargo'] = $row['cargo'];
    header("Location: ../ponencias.php");
}else{
        header("Location: ../revisor.php");
    }
?>