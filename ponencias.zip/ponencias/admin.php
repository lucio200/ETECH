<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SISTEMA WEB PONENCIAS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
   
  
  </head>
  <body>
  





<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
   
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="ponencias.php">Ponencias</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="revisor.php">Revisores</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Mantenimientos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registroponencias.php">Ponencias</a></li>
            <li><a class="dropdown-item" href="registrorevisor.php">Revisores</a></li>
            <li><a class="dropdown-item" href="registroeje.php">Ejes</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="medico.php">Reportes</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-disabled="true">Preguntas</a>
        </li>
      </ul>
   
    </div>
  </div>
</nav>



<div class="contenedor">
<h2>PERFIL ADMINISTRADOR</h2>


<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT * FROM ponencias p 
  INNER JOIN eje e ON p.ced_po = e.cedula_po
  INNER JOIN revisores r ON r.ced_rev  = e.cedula_rev    
  ORDER BY p.ced_po DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){ 
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
    SELECT * FROM ponencias p
    INNER JOIN eje e ON p.ced_po = e.cedula_po
    INNER JOIN revisores r ON r.ced_rev  = e.cedula_rev
    WHERE (p.nom_po LIKE :campo OR p.ced_po LIKE :campo;) 
    '
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>

<div class="contenedor">
	
    <div class="container text-center">
    <h2>ASIGNACIÓN DE REVISORES</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="Buscar Nombre o Cédula" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
				<a href="ponencias.php" class="btn btn__nuevo">Nuevo</a>
        <a href="index.php" class="btn btn__nuevo" name ="bnt_salir">Salir</a>
		
		</div>
		<table class="table table-bordered">
    <thead class="table-light">
			<tr class="head">
				
				<td>Nombre Ponente</td>
				<td>Nombre del Eje</td>
				<td>Fecha de Entrega</td>
        <td>Revisor Asignado</td>
				
				<td colspan="3">Acción</td>
			</tr>
    </thead>
			<?php foreach($resultado as $fila):?>
				<tr >
				<td><?php echo $fila['nom_po'] . ' ' . $fila['apell_po']; ?></td>
					<td><?php echo $fila['nombre_eje']; ?></td>
					<td><?php echo $fila['fechaentrega_eje']; ?></td>
          <td><?php echo $fila['nom_rev'] . ' ' . $fila['apell_rev']; ?></td>
					<td><a href="actualizar.php?id_eje=<?php echo $fila['id_eje']; ?>"  class="btn btn-dark" onclick="eliminarFila(this)">Asignar Revisor</a></td>
				</tr>
			<?php endforeach ?>

		</table>
	</div>
      </form>


<script>
function eliminarFila(boton) {
    // Obtener la fila a la que pertenece el botón
    var fila = boton.closest('tr');
    // Eliminar la fila de la tabla
    fila.remove();
}
</script>


<script src ="/incelab/js/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script> 

</body>
</html>