-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-04-2024 a las 15:49:58
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `acceso`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

CREATE TABLE `cargo` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`id`, `descripcion`) VALUES
(1, 'Administrador'),
(3, 'Revisor'),
(4, 'Ponente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `cat_id` int(11) NOT NULL,
  `cat_nombre` varchar(20) DEFAULT NULL,
  `cat_estado` char(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `dep_id` int(11) NOT NULL,
  `dep_nombre` varchar(20) DEFAULT NULL,
  `dep_estado` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eje`
--

CREATE TABLE `eje` (
  `id_eje` int(11) NOT NULL,
  `nombre_eje` varchar(100) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetype` varchar(100) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `resumen_eje` varchar(250) NOT NULL,
  `fechaentrega_eje` date NOT NULL,
  `estado_eje` varchar(100) NOT NULL,
  `observa_eje` varchar(250) NOT NULL,
  `id_ponencia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `eje`
--

INSERT INTO `eje` (`id_eje`, `nombre_eje`, `filename`, `filesize`, `filetype`, `upload_date`, `resumen_eje`, `fechaentrega_eje`, `estado_eje`, `observa_eje`, `id_ponencia`) VALUES
(17, 'Desarrollo Sostenible', '1e0f65eb20acbfb2_20220617_082137RxkD1.pdf', 6095955, 'application/pdf', '2024-04-20 03:40:37', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', '2024-04-17', 'Aprobado', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', 1),
(26, 'Desarrollo Sostenible', '04. El lenguaje de programación C# autor José Antonio González Seco.pdf', 1731714, 'application/pdf', '2024-04-20 04:08:03', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', '2024-04-17', 'Rechazado', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', 1),
(29, 'Desarrollo Sostenible', '03. Curso .NET con C# autor Universidad de Alicante.pdf', 1740676, 'application/pdf', '2024-04-20 04:08:20', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', '2024-04-17', 'Aprobado', 'La Innovación Tecnológica consiste en la implementación de ideas nuevas en una institución', 2),
(39, 'Innovación Educativa en la Formación Técnica y Tecnológica', '1e0f65eb20acbfb2_20220617_082137RxkD1.pdf', 6095955, 'application/pdf', '2024-04-19 00:25:02', 'ljkhjkhkjhjk', '2024-04-18', '0', '', 20),
(41, 'Desarrollo Integral para la Salud', '1e0f65eb20acbfb2_20220617_082137RxkD1.pdf', 6095955, 'application/pdf', '2024-04-20 06:52:19', 'Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies like screen readers. Please ensure the meaning is obvious from the content itself (e.g., the visible text with a sufficient co', '2024-04-20', '', '', 20),
(49, 'Desarrollo Integral para la Salud', '1e0f65eb20acbfb2_20220617_082137RxkD1.pdf', 6095955, 'application/pdf', '2024-04-20 08:20:02', 'Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies like screen readers. Please ensure the meaning is obvious from the content itself (e.g., the visible text with a sufficient co', '2024-04-20', '', '', 33),
(52, 'Desarrollo Sostenible', '22. PHP autor Juan Pavón Mestras.pdf', 203042, 'application/pdf', '2024-04-22 03:39:16', 'asdasdsadasd', '2024-04-21', 'Rechazado', 'asdasdsad@asdasdsa.com', 35),
(57, 'Desarrollo Sostenible', 'MAMATUNCH JHONY.pdf', 141827, 'application/pdf', '2024-04-22 19:39:04', 'gdgdfgdsgds@dfg', '2024-04-22', '', '', 35);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `empre_id` int(11) NOT NULL,
  `empre_nombre` varchar(20) DEFAULT NULL,
  `empre_ruc` int(11) DEFAULT NULL,
  `empre_estado` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

CREATE TABLE `estados` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`id`, `descripcion`) VALUES
(1, 'Aprobado'),
(2, 'Rechazado'),
(3, 'Aprobado con Observaciones');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `files`
--

CREATE TABLE `files` (
  `id_file` int(11) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `filesize` int(11) NOT NULL,
  `filetype` varchar(100) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `files`
--

INSERT INTO `files` (`id_file`, `filename`, `filesize`, `filetype`, `upload_date`) VALUES
(1, 'part 1.png', 192044, 'image/png', '2023-07-26 06:13:41'),
(2, 'part 1.png', 192044, 'image/png', '2023-07-26 06:45:44'),
(3, 'part 2.png', 190883, 'image/png', '2023-07-26 06:52:46'),
(4, 'part 3.png', 192457, 'image/png', '2023-07-26 06:52:57'),
(5, 'part 3.png', 192457, 'image/png', '2023-07-26 06:53:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ponencias`
--

CREATE TABLE `ponencias` (
  `id_po` int(11) NOT NULL,
  `nombre_po` varchar(45) NOT NULL,
  `apellido_po` varchar(45) NOT NULL,
  `cedula_po` int(11) NOT NULL,
  `celular_po` int(11) NOT NULL,
  `correo_po` varchar(45) NOT NULL,
  `institucion_po` varchar(45) NOT NULL,
  `titulo_po` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ponencias`
--

INSERT INTO `ponencias` (`id_po`, `nombre_po`, `apellido_po`, `cedula_po`, `celular_po`, `correo_po`, `institucion_po`, `titulo_po`) VALUES
(1, 'Juan', 'Chasi', 1708984220, 998957504, 'juanch@itsjapon.edu.ec', 'Instituto Libertad', 'Investigacion'),
(2, 'Adrian', 'Alvarez', 1719215856, 98565254, 'adal@gmail.com', 'Japon', 'Inveestigacion'),
(20, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(21, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(22, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(23, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(24, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(25, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(26, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(27, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(28, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(29, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(30, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(31, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(32, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(33, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(34, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion'),
(35, 'Ricardo', 'Arias', 1719213108, 998957504, 'riarias@itsjapon.edu.ec', 'Japon', 'Inveestigacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `prod_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `mant_id` int(11) NOT NULL,
  `usu_id` int(11) NOT NULL,
  `prod_detalle` varchar(20) DEFAULT NULL,
  `prod_estado` varchar(20) DEFAULT NULL,
  `prod_fecha_ingreso` varchar(20) DEFAULT NULL,
  `prod_fecha_salida` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revisores`
--

CREATE TABLE `revisores` (
  `id_rev` int(11) NOT NULL,
  `nombres_rev` varchar(45) NOT NULL,
  `apellidos_rev` varchar(45) NOT NULL,
  `cedula_rev` varchar(45) NOT NULL,
  `celular_rev` varchar(45) NOT NULL,
  `correo_rev` varchar(45) NOT NULL,
  `areaconocimiento` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `revisores`
--

INSERT INTO `revisores` (`id_rev`, `nombres_rev`, `apellidos_rev`, `cedula_rev`, `celular_rev`, `correo_rev`, `areaconocimiento`) VALUES
(1, 'Ricardo', 'Arias', '1719213108', '0991408984', 'riariasq@itsjapon.edu.ec', 'Desarrollo'),
(2, 'Juan', 'Chasi', '1789563248', '0658952658', 'jchasi@itsjapon.edu.ec', 'Investigación'),
(6, 'Lucia', 'Begnini', '1711262798', '0992526110', 'lbegnini@itsjapon.edu.ec', 'Educación');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `usu_id` int(11) NOT NULL,
  `usu_nom` varchar(45) DEFAULT NULL,
  `usu_apell` varchar(45) DEFAULT NULL,
  `usu_mail` varchar(45) DEFAULT NULL,
  `usu_telf` int(11) DEFAULT NULL,
  `usu_estado` char(20) DEFAULT NULL,
  `empre_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`usu_id`, `usu_nom`, `usu_apell`, `usu_mail`, `usu_telf`, `usu_estado`, `empre_id`, `dep_id`, `cargo_id`) VALUES
(7, 'fdfgf', 'dfg', 'riv@gmail.com', 435345, 'activo', 0, 0, 0),
(8, 'dsadasd', 'asdsads', 'dasds@gmail.com', 12321321, 'activo', 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `contrasenia` varchar(45) NOT NULL,
  `id_cargo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contrasenia`, `id_cargo`) VALUES
(1, '1719213108', '12345', 1),
(8, '1756579965', '1756579965', 4),
(9, '1711262798', '1711262798', 3),
(29, '3322116655', '12345', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indices de la tabla `eje`
--
ALTER TABLE `eje`
  ADD PRIMARY KEY (`id_eje`),
  ADD KEY `cedula_po` (`id_ponencia`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`empre_id`);

--
-- Indices de la tabla `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id_file`);

--
-- Indices de la tabla `ponencias`
--
ALTER TABLE `ponencias`
  ADD PRIMARY KEY (`id_po`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indices de la tabla `revisores`
--
ALTER TABLE `revisores`
  ADD PRIMARY KEY (`id_rev`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usu_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_cargo` (`id_cargo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `eje`
--
ALTER TABLE `eje`
  MODIFY `id_eje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `estados`
--
ALTER TABLE `estados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `files`
--
ALTER TABLE `files`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ponencias`
--
ALTER TABLE `ponencias`
  MODIFY `id_po` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de la tabla `revisores`
--
ALTER TABLE `revisores`
  MODIFY `id_rev` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `usu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eje`
--
ALTER TABLE `eje`
  ADD CONSTRAINT `eje_ibfk_1` FOREIGN KEY (`id_ponencia`) REFERENCES `ponencias` (`id_po`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_cargo`) REFERENCES `cargo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
