<?php
$usuario = $_POST['usuario'];
$password = $_POST['password'];
//echo $usuario."-".$password_user;

if($usuario == "rick" && $password == 1){
    ?>
    <div class = "alert alert-danger" role= "alert"> Acceso Correcto</div>
    <?php
}else {
    ?>
    <div class = "alert alert-danger" role= "alert"> Acceso Incorrecto</div>
    <?php   
}


?>