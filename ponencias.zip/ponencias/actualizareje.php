<?php
	include_once 'conexion.php';

	if(isset($_GET['id_eje'])){
		$id_eje=(int) $_GET['id_eje'];

		$buscar_id=$con->prepare('SELECT * FROM eje WHERE id_eje = :id_eje LIMIT 1');
		$buscar_id->execute(array(
			':id_eje'=>$id_eje
		));
		$resultado=$buscar_id->fetch();
	}else{
		header('Location: registroeje.php');
	}

	$id_eje=(int) $_GET['id_eje'];
	/*if(isset($_POST['guardar'])){
		$nombre_eje=$_POST['nombre_eje'];
		$estado_eje=$_POST['estado_eje'];
        $observa_eje=$_POST['observa_eje'];
		$id_eje=(int) $_GET['id_eje'];

		if(!empty($nombre_eje) && !empty($estado_eje) && !empty($observa_eje)){
			
				$consulta_update=$con->prepare(' UPDATE eje SET  
					nombre_eje=:nombre_eje,
					estado_eje=:estado_eje,
					observa_eje=:observa_eje
					WHERE id_eje=:id_eje;'
				);
				$consulta_update->execute(array(
					':nombre_eje' =>$nombre_eje,
					':estado_eje' =>$estado_eje,
					':observa_eje' =>$observa_eje,
					':id_eje' =>$id_eje
				));
				$mensaje = "!Ingresado correctamente";
echo "<script type='text/javascript'> 
        alert('$mensaje');
        window.location.href = 'menurevisor.php';
      </script>";
               
			
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}
	}*/
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<title>Editar Ponencia</title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<div class="contenedor">
		<h2>Aprobación de Ejes</h2>
		<form action="uploadrev.php" method="POST" enctype="multipart/form-data">
			<div class="">
			<input type="hidden" name="id_eje" value="<?php echo $id_eje; ?>">
				<input type="text" name="nombre_eje" value="<?php if($resultado) echo $resultado['nombre_eje']; ?>" class="input__text">
                <select name="estado_eje" class="form-select" aria-label="Default select example">
          <option>Estado</option>
                        <option>Aceptado</option>
                        <option>Rechazado</option>
                        <option>Aceptado con Observación</option>
                    </select>
			</div>
			<div class="form-group">	
            <br><textarea name="observa_eje" class="form-control" placeholder="Observaciones" rows="8" cols="59" value="<?php if($resultado) echo $resultado['observa_eje']; ?>"></textarea>	
				</div>
			<div class="container mt-5">
			     <label>Solo admite archivo formato PDF Máximo 25MB</label>
				<input type="file" class="form-control" name="file" id = "file">
			</div>
			<div class="btn__group">
				<a href="menurevisor.php" class="btn btn__danger">Salir</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>
</body>
</html>