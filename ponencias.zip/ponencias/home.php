
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Login</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/cabecera.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">

</head>

<body>
    
<form action="validar.php" method="post">
<h1 class="animate__animated animate__backInLeft">SISTEMA WEB PONENCIAS</h1>
<p>Usuario<input type="text" placeholder= "Ingresar Cédula" name="cedula" /></p>
<p>Contraseña<input type="password" placeholder= "Ingresar Clave" name="contrasenia" /></p>
<p>-</p>
<input type="submit" value="Ingresar" class="btn btn-info"/>
<p>-</p>
<a href="registro.php" class="btn__update">Registrarse</a>
<p>-</p>
<a href="" class="btn__update">Olvido Clave</a>
<p>-</p>
</form>
</body>
</html>
