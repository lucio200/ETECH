

<?php
//conexion base de datos
require 'conexion1.php';
$perfiles = $mysqli->query("SELECT id, descripcion FROM cargo WHERE id != 1");
?>




<?php 
include_once 'conexion.php'; 

if(isset($_POST['guardar'])){
    $cedula = $_POST['cedula'];
    $contrasenia = $_POST['contrasenia'];
    $id_cargo = $_POST['id_cargo'];
    
    if(!empty($cedula) && !empty($contrasenia) && !empty($id_cargo)){
        if(!filter_var($cedula,FILTER_VALIDATE_INT)){                
            echo "<script> alert('Usuario no válido');</script>";
        } else {
            // Consulta para verificar si el usuario ya existe
            $consulta_existencia = $con->prepare('SELECT COUNT(*) FROM usuarios WHERE cedula = ?');
            $consulta_existencia->execute([$cedula]);
            $resultado = $consulta_existencia->fetchColumn();
            
            if($resultado > 0){
                echo "<script> alert('El usuario ya existe');</script>";
            } else {
                // Insertar el usuario en la base de datos
                $consulta_insert=$con->prepare('INSERT INTO usuarios(cedula, contrasenia, id_cargo) VALUES(:cedula,:contrasenia,:id_cargo)');
                $consulta_insert->execute(array(
                    ':cedula' =>$cedula,
                    ':contrasenia' =>$contrasenia,
                    ':id_cargo' =>$id_cargo
                ));
                $mensaje = "!Ingresado correctamente";
                echo "<script type='text/javascript'> 
                        alert('$mensaje');
                        window.location.href = 'index.php';
                      </script>";
                
            }
        }
    } else {
        echo "<script> alert('Los campos están vacíos');</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro de Usuarios</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>Registrar usuario</h2>
		<form action="" method="post">

			<div class="form-group">				
			<input type="text" name="cedula" placeholder="Ingresar Cédula" class="input__text">
			</div>
			<div class="form-group">							
			<input type="password" name="contrasenia" placeholder="Ingresar Clave" class="input__text">
			<a href="index.php" class="btn btn__danger">Regresar</a>
			<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">			
</div>


<label>Seleccione el Perfil</label>	

<select name = "id_cargo" class = "form-group">
<option>Seleccionar el Perfil</option>
<?php
while($row = $perfiles->fetch_assoc()){ ?>
<option value ="<?php echo $row['id'];?>"> <?php echo $row['descripcion'];?></option>
<?php }?>
</select>

</form>
</div>	
</body>
</html>