<?php
//sesion de seguridad
/*session_start();
error_reporting(0);
$varsesion=$_SESSION['usuario'];
if($varsesion==null || $varsesion==''){
header("location:../index.php");
die();
}*/
?>



<?php
	include 'conexion1.php';
  include 'conexion.php';
  include("correo.php");
	$sql= "select * from ponencias p 
  INNER JOIN eje e ON p.ced_po = e.cedula_po
  INNER JOIN revisores r ON r.ced_rev = e.cedula_rev
  ";
 
  $resultado1 =mysqli_query($conexion,$sql);
?>

<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT * FROM ponencias p 
  INNER JOIN eje e ON p.ced_po = e.cedula_po
  INNER JOIN revisores r ON r.ced_rev = e.cedula_rev
  ORDER BY p.ced_po DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT * FROM ponencias p 
      INNER JOIN eje e ON p.ced_po = e.cedula_po 
      INNER JOIN revisores r ON r.ced_rev = e.cedula_rev
      WHERE p.nom_po LIKE :campo OR p.ced_po LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>
<?php
//database connection details

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "acceso";

 $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);


 if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

 //Fetch the uploaded files from the database

 $sql = "select * from eje e 
 INNER JOIN ponencias p ON e.cedula_po  = p.ced_po
 INNER JOIN revisores r ON r.ced_rev = e.cedula_rev
 ";
 $result = $conn->query($sql);

?>


<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MENU REVISOR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  
  </head>
  <body>
  
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
      <img src="\incelab\IMG\Logo.ico" alt="Incetronix" width="30" height="24">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="revisor.php">Datos Del Revisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href=""></a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Gestión
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registroponencias.php">Envío de Mail</a></li>
            <li><a class="dropdown-item" href="registrorevisor.php">Estados</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="medico.php">Reportes</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-disabled="true">Preguntas</a>
        </li>
      </ul>
     
      </form>
    </div>
  </div>
</nav>


<div class="contenedor">
<h2>BIENVENIDO AL MENÚ DEL REVISOR</h2>
<div class="container text-center">
		<h2>LISTA DE PONENCIAS</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				
				<a href="revisor.php" class="btn btn-success">Registro de Datos</a>
        <a href="https://itsjaponec-my.sharepoint.com/:x:/g/personal/riariasq_itsjapon_edu_ec/EVLsnVMRSVZPp1LhTvaJwcEBMuYH3sXmSdhvhthwLHB3sQ?e=uyEsGg" target='_blank' class="btn btn-success">Rubrica</a>
        <a href="index.php" class="btn btn-success">Salir</a>
			
		</div>
		<table class="table table-bordered">
       <thead class="table-light">
			<tr class="head">
			<td>Nombre</td>
				<td>Apellido</td>
        <td>Título</td>
			  <td>Nombre del Eje</td>   
        <td>Fecha de Entrega</td>
        <td>Revisor Asignado</td>           
				<td colspan="3">Acciones</td> 
<!--<td colspan="4">Observaciones</td>-->  
      </tr>  
       </thead>
			
        <?php
                // Display the uploaded files and download links
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $file_path = "uploads/" . $row['filename'];
                        ?>
				<tr >
					
				<td><?php echo $row['nom_po']; ?></td>
					<td><?php echo $row['apell_po']; ?></td>
          <td><?php echo $row['tit_po']; ?></td>
          <td><?php echo $row['nombre_eje']; ?></td>
          <td><?php echo $row['fechaentrega_eje']; ?></td>
          <td colspan="3"><?php echo $row['nom_rev'] . ' ' . $row['apell_rev']; ?></td>
					<td><a href="<?php echo $file_path; ?>" class="btn btn-light" download>Descargar</a></td>
          <!--<td><input type="submit" value="Enviar" name = "enviar" class="btn btn-light"></td>-->
          <td><a href="registroeje.php"  class="btn btn-dark" >Enviar Aprobar</a></td>
          
          <!-- <td> <select name="estado_eje" class="form-select" aria-label="Default select example">
         <option>Estado</option>
                        <option>Aprobado</option>
                        <option>Rechazado</option>
                        <option>Aprobado con Observación</option>
                    </select></td>
           <td><textarea name="observa_eje"></textarea>	</td>-->
				</tr>
     
        <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="4">No encuentra el documento.</td>
                    </tr>
                    <?php
                }
                ?>

		</table>
      

	</div>

  </form>




<script src ="/incelab/js/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script> 

</body>
</html>