<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a file was uploaded without errors
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $target_dir = "uploads/"; // Change this to the desired directory for uploaded files
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is allowed (you can modify this to allow specific file types)
        $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf");
        if (!in_array($file_type, $allowed_types)) {
            echo "Solo Admite formato PDF";
            exit();
            header('Location: menuponencias.php');
        } else {
            // Move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                // File upload success, now store information in the database
                $filename = $_FILES["file"]["name"];
                $filesize = $_FILES["file"]["size"];
                $filetype = $_FILES["file"]["type"];

                // Database connection
                $db_host = "localhost";
                $db_user = "root";
                $db_pass = "";
                $db_name = "acceso";

                $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

				  
				$nombre_eje = $_POST['nombre_eje'];
                $tema_eje = $_POST['tema_eje'];
                $resumen_eje = $_POST['resumen_eje'];
                $fechaentrega_eje = $_POST['fechaentrega_eje'];
				$estado_eje=$_POST['estado_eje'];
				$observa_eje=$_POST['observa_eje'];
                $filenamer=$_POST['filenamer'];
                $filesizer=$_POST['filesizer'];
                $filetyper=$_POST['filetyper'];
				$cedula_po = $_POST['cedula_po'];
                $cedula_rev = $_POST['cedula_rev'];
                
					
                $sql = "INSERT INTO eje (nombre_eje, tema_eje, resumen_eje, fechaentrega_eje, estado_eje, observa_eje, filenamer, filesizer, filetyper, filename, filesize, filetype, cedula_po, cedula_rev) VALUES ('$nombre_eje', '$tema_eje', '$resumen_eje', '$fechaentrega_eje', '$estado_eje', '$observa_eje',  '$filenamer', $filesizer, '$filetyper',  '$filename', $filesize, '$filetype', '$cedula_po', '$cedula_rev')";

                if ($conn->query($sql) === TRUE) {
                    echo "The file " . basename($_FILES["file"]["name"]) . " ";
                    $mensaje = "!Ingresado correctamente";
                    echo "<script type='text/javascript'> 
                            alert('$mensaje');
                            window.location.href = 'menuponencias.php';
                          </script>";
                } else {
                    echo "Los sentimos a ocurrido un error al cargar en la base de datos " . $conn->error;
                }

                $conn->close();
            } else {
                echo "No se ha podido cargar la informaci贸n";
            }
        }
    } else {
        echo "Documento no Cargado";
    }
}
?>
