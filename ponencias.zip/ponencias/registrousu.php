<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT *FROM users ORDER BY usu_id DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT *FROM users WHERE usu_nom LIKE :campo OR usu_apell LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Inicio</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>REGISTRO DE PONENCIAS</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="buscar nombre o apellidos" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
				<a href="insertar.php" class="btn btn__nuevo">Nuevo</a>
			</form>
		</div>
		<table>
			<tr class="head">
				<td>Id</td>
				<td>Nombre</td>
				<td>Apellidos</td>
				<td>Telefono</td>
				<td>Correo</td>
				<td>Estado</td>
				<td colspan="3">Accion</td>
			</tr>
			<?php foreach($resultado as $fila):?>
				<tr >
					<td><?php echo $fila['usu_id']; ?></td>
					<td><?php echo $fila['usu_nom']; ?></td>
					<td><?php echo $fila['usu_apell']; ?></td>
					<td><?php echo $fila['usu_telf']; ?></td>
					<td><?php echo $fila['usu_mail']; ?></td>
					<td><?php echo $fila['usu_estado']; ?></td>
					<td><a href="actualizar.php?id=<?php echo $fila['usu_id']; ?>"  class="btn__update" >Editar</a></td>
					<td><a href="borrar.php?id=<?php echo $fila['usu_id']; ?>" class="btn__delete">Eliminar</a></td>
					<td><a href="actualizar.php" class="btn__update">Descargar</a></td>
				</tr>
			<?php endforeach ?>

		</table>
	</div>
</body>
</html>
