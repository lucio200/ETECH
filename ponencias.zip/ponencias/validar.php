
<?php
session_start();

// Verificar si el usuario está autenticado
/*if (!isset($_SESSION['usuario'])) {
    // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
    header("Location: index.php");
    exit(); // Detener la ejecución del script después de la redirección
}*/


if (isset($_POST['cedula']) && isset($_POST['contrasenia'])) {
    include('db.php'); // Incluye el archivo de conexión a la base de datos
    
    $cedula = $_POST['cedula'];
    $contrasenia = $_POST['contrasenia'];

    $conexion = mysqli_connect("127.0.0.1", "root", "", "acceso");
    
    // Evitar la inyección SQL utilizando consultas preparadas
    $consulta = "SELECT * FROM usuarios WHERE cedula=? AND contrasenia=?";
    $stmt = mysqli_prepare($conexion, $consulta);
    mysqli_stmt_bind_param($stmt, "ss", $cedula, $contrasenia);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    
    // Verificar si se encontró un usuario con las credenciales proporcionadas
    if ($fila = mysqli_fetch_assoc($resultado)) {
        // Redirigir según el tipo de usuario
        switch ($fila['id_cargo']) {
            case 1:
                header("Location: admin.php");
                exit();
            case 2:
                header("Location: cliente.php");
                exit();
            case 3:
                header("Location: menurevisor.php");
                exit();
            case 4:
                header("Location: menuponencias.php");
                exit();
            default:
                break;
        }
    } else {
        // Si las credenciales son incorrectas, mostrar un mensaje de error
        header("Location: index.php?error=1");
        exit();
    }
} else {
    // Si no se enviaron las credenciales, redirigir al formulario de inicio de sesión
    header("Location: index.php");
    exit();
}
?>