<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Conextion</title>
</head>

<body>
<?php
	$database="acceso";
	$user='root';
	$password='';
try {	
	$con=new PDO('mysql:host=localhost;dbname='.$database,$user,$password);

} catch (PDOException $e) {
	echo "Error".$e->getMessage();
}


?>

<?php

$mysqli = new mysqli("localhost", "root","","acceso");
if ($mysqli->connect_error){
echo "Error de Conexión". $mysqli->connect_error;
exit;

}
?>

<?php

$dbname="acceso";
$dbuser="root";
$dbhost="localhost";
$dbpass="";
$conexion=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);


?>


<?php

$con = new mysqli('localhost', 'root', '', 'acceso');
if ($con->connect_errno) {
    die('fail');
}

function file_name($string) {

    // Tranformamos todo a minusculas

    $string = strtolower($string);

    //Rememplazamos caracteres especiales latinos

    $find = array('á', 'é', 'í', 'ó', 'ú', 'ñ');

    $repl = array('a', 'e', 'i', 'o', 'u', 'n');

    $string = str_replace($find, $repl, $string);

    // Añadimos los guiones

    $find = array(' ', '&', '\r\n', '\n', '+');
    $string = str_replace($find, '-', $string);

    // Eliminamos y Reemplazamos otros carácteres especiales

    $find = array('/[^a-z0-9\-<>]/', '/[\-]+/', '/<[^>]*>/');

    $repl = array('', '-', '');

    $string = preg_replace($find, $repl, $string);

    return $string;
}
?>





</body>
</html>