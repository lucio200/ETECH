<?php 
	include_once 'conexion.php';
	
	if(isset($_POST['guardar'])){
		$resumen=$_POST['resumen'];
		$trabajo=$_POST['trabajo'];
		$fechaentrega=$_POST['fechaentrega'];
		$estado=$_POST['estado'];
		

		if(!empty($resumen) && !empty($trabajo) && !empty($fechaentrega) && !empty($estado) ){
			if(!filter_var($correo,FILTER_VALIDATE_EMAIL)){
				echo "<script> alert('Correo no valido');</script>";
			}else{
				$consulta_insert=$con->prepare('INSERT INTO eje(resumen, trabajo, fechaentrega, estado_po) VALUES(:resumen,:trabajo,:fechaentrega,:estado)');
				$consulta_insert->execute(array(
					':resumen' =>$resumen,
					':trabajo' =>$trabajo,
					':fechaentrega' =>$fechaentrega,
					':estado' =>$estado
				));
				header('Location: menuponencias.php');
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}

	}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro de Eje Temático</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>Ingreso de Eje Temático</h2>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="resumen" placeholder="Ingrese un Resumen" class="input__text">
				<input type="text" name="trabajo" placeholder="Trabajo" class="input__text">
			</div>
			<div class="form-group">
				<input type="text" name="fechaentrega" placeholder="Fecha de Entrega" class="input__text">
				<input type="text" name="estado" placeholder="Estado" class="input__text">
			</div>
			Archivo:
			<input type="file" name="archivo" />
			<input type="submit" name="cargar" value="Cargar Documento" class="btn btn__primary">
			<div class="btn__group">
				<a href="index.php" class="btn btn__danger">Cancelar</a>
				<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			</div>
		</form>
	</div>

	<?php
     $dir = "files/";
      $ruta_carga = $dir . $_FILES['archivo']['name'];
	 echo $_FILES['archivo']['name'];
	 move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta_carga);

	?>
</body>
</html>
