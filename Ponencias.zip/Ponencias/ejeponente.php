<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT p.id_po, p.nombre_po, p.apellido_po, p.cedula_po, p.institucion_po, e.trabajo_eje, e.fechaentrega_eje, e.estado_eje  FROM ponencias p, eje e ORDER BY id_po DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
        p.id_po, p.nombre_po, p.apellido_po, p.cedula_po, p.institucion_po, e.trabajo_eje, e.fechaentrega_eje, e.estado_eje  FROM ponencias p, eje e WHERE nombre_po LIKE :campo OR cedula_po LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Inicio</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>REVISIÓN TRABAJOS</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="buscar nombre o cédula" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
				<a href="ponencias.php" class="btn btn__nuevo">Nuevo</a>
			</form>
		</div>
		<table>
			<tr class="head">
				<td>Id</td>
				<td>Nombre</td>
				<td>Apellido</td>
				<td>Cédula</td>
				<td>Institución</td>
                <td>Fecha_Entrega</td>
				<td>Estado</td>
               
				<td colspan="3">Acción</td>
                <td colspan="3">Observación</td>
			</tr>
			<?php foreach($resultado as $fila):?>
				<tr >
					<td><?php echo $fila['id_po']; ?></td>
					<td><?php echo $fila['nombre_po']; ?></td>
					<td><?php echo $fila['apellido_po']; ?></td>
					<td><?php echo $fila['cedula_po']; ?></td>
					<td><?php echo $fila['institucion_po']; ?></td>
                    <td><?php echo $fila['fechaentrega_eje']; ?></td>
					<td><?php echo $fila['estado_eje']; ?></td>
					<td><select>
                        <option>Aprobado</option>
                        <option>Rechazado</option>
                        <option>Aprobado con Observaciones</option>
                    </select></td>
					<td><a href="actualizar.php" class="btn__update">Descargar</a></td>
				</tr>
			<?php endforeach ?>

		</table>
        <div class="contenedor">
		<h2>Observaciones</h2>
		<form action="" method="post">
			<div class="form-group">
				<input type="text" name="observaciones" placeholder="Observaciones" class="input__text">
				
			</div>

	</div>
</body>
</html>