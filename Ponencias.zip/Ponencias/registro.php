<?php 
	include_once 'conexion.php';
	
	if(isset($_POST['guardar'])){
		$usuario=$_POST['usuario'];
		$clave=$_POST['clave'];
		$id_cargo=$_POST['descripcion'];
		

		if(!empty($usuario) && !empty($clave) && !empty($id_cargo) ){
			if(!filter_var($usuario,FILTER_VALIDATE_EMAIL)){
				echo "<script> alert('Correo no valido');</script>";
			}else{
				$consulta_insert=$con->prepare('INSERT INTO usuarios(usuario, clave, id_cargo) VALUES(:usuario,:clave,:id_cargo)');
				$consulta_insert->execute(array(
					':usuario' =>$usuario,
					':clave' =>$clave,
					':id_cargo' =>$id_cargo,
				));
				header('Location: index.php');
			}
		}else{
			echo "<script> alert('Los campos estan vacios');</script>";
		}

	}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro de Usuarios</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>Registrar usuario</h2>
		<form action="" method="post">

			<div class="form-group">				
			<input type="text" name="usuario" placeholder="Ingrese su Cédula" class="input__text">
			</div>

			<div class="form-group">	
						
			<input type="password" name="clave" placeholder="Clave" class="input__text">
			<a href="index.php" class="btn btn__danger">Cancelar</a>
			<input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
			
</div>


<label>Seleccione el Perfil</label>	

<select name = "cargo" class = "form-group">
<option value = "Ponentes">  Revisor</option>
<option value = "Revisores"> Ponente</option>
</select>

<select name="id_cargo" class="form-group">
				<?php
include("conexion.php");
$getcargo1 = "select * from cargo order by id";
$getcargo2 = mysql_query($getcargo1);


while( $row = mysql_fetch_array($getcargo2)){
$id = $row['id'];
$descripcion = $row['descripcion'];
?>

<option value ="<?php echo $id; ?>"> <?php echo $descripcion." "; ?></option>
<?php
}
				?>
</select>








</form>

</div>	

	
</body>
</html>