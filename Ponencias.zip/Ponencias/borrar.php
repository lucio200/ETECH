<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BORRAR USUARIOS</title>
</head>

<body>
<?php 

	include_once 'conexion.php';
	if(isset($_GET['id'])){
		$id=(int) $_GET['id'];
		$delete=$con->prepare('DELETE FROM users WHERE usu_id=:id');
		$delete->execute(array(
			':id'=>$id
		));
		header('Location: admin.php');
	}else{
		header('Location: admin.php');
	}
 ?>
</body>
</html>
