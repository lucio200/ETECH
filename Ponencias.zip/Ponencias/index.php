<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Login</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/cabecera.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">

</head>

<body>
<form action="validar.php" method="post">
<h1 class="animate__animated animate__backInLeft">SISTEMA WEB PONENCIAS</h1>
<p>Usuario<input type="text" placeholder= "Ingrese numero de cédula" name="nombre" /></p>
<p>Contrasenia<input type="password" placeholder= "Ingrese su clave" name="contrasenia" /></p>
<p>-</p>
<label for=""><a href="registro.php">Registrarse</a></label>
<p>-</p>
<label for=""><a href="#">Olvido Clave</label>
<p>-</p>
<input type="submit" value="Ingresar" />

</form>
</body>
</html>
