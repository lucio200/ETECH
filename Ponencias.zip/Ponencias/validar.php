<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Validar</title>
</head>
<body>

<?php
include('db.php');
$nombre=$_POST['nombre'];
$contrasenia=$_POST['contrasenia'];
session_start();
$SESSION['nombre']=$nombre;


$conexion=mysqli_connect("127.0.0.1","root","","acceso");
$consulta="SELECT*FROM usuarios where usuario='$nombre' and contrasenia = '$contrasenia'";
$resultado=mysqli_query($conexion,$consulta);
//$filas=mysqli_num_rows($resultado);
$filas=mysqli_fetch_array($resultado);
if($filas['id_cargo']==1){//administrador
header("location:admin.php");
}
else if($filas['id_cargo']==2){//cliente
header("location:cliente.php");
}
else if($filas['id_cargo']==3){//medico
    header("location:menurevisor.php");
    }
    else if($filas['id_cargo']==4){//admision
        header("location:menuponencias.php");
        }
else{
?>
<?php
include("index.php");
?>
<h1 class="bad">ERROR DE LA AUTENTICACION</h1>
<?php
}

mysqli_free_result($resultado);
mysqli_close($conexion);
?>
</body>
</html>
