<?php
	include_once 'conexion.php';

	$sentencia_select=$con->prepare('SELECT u.usu_id, u.usu_nom, u.usu_apell, u.usu_telf, u.usu_mail, u.usu_estado, r.nombres_rev  FROM users u, revisores r ORDER BY usu_id DESC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchAll();

	// metodo buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('
			SELECT u.usu_id, u.usu_nom, u.usu_apell, u.usu_telf, u.usu_mail, u.usu_estado, r.nombres_rev  FROM users u, revisores r WHERE usu_nom LIKE :campo OR usu_apell LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' =>"%".$buscar_text."%"
		));

		$resultado=$select_buscar->fetchAll();

	}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>REVISOR</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2>VISTA GENERAL</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="buscar nombre o apellidos" 
				value="<?php if(isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
			</form>
		</div>
<table>
<tr class="head">
				<td>Id</td>
				<td>Nombre</td>
				<td>Apellidos</td>
				<td>Telefono</td>
				<td>Correo</td>
				<td>Estado</td>
                <td>Asignado</td>
				
			</tr>
			<?php foreach($resultado as $fila):?>
				<tr >
					<td><?php echo $fila['usu_id']; ?></td>
					<td><?php echo $fila['usu_nom']; ?></td>
					<td><?php echo $fila['usu_apell']; ?></td>
					<td><?php echo $fila['usu_telf']; ?></td>
					<td><?php echo $fila['usu_mail']; ?></td>
					<td><?php echo $fila['usu_estado']; ?></td>
					<td><?php echo $fila['nombres_rev']; ?></td>
				</tr>
			<?php endforeach ?>

		</table>
	</div>
</body>
</html>