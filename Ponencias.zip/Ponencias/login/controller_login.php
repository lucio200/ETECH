<?php
$usuario = $_POST['usuario'];
$password_user = $_POST['password_user'];
//echo $usuario."-".$password_user;

if($usuario == "rick" && $password_user == 1){
    ?>
    <div class = "alert alert-danger" role= "alert"> Acceso Correcto</div>
    <?php
}else {
    ?>
    <div class = "alert alert-danger" role= "alert"> Acceso Incorrecto</div>
    <?php   
}


?>